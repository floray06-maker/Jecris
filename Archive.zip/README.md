# J'écris en français — parcours A1 → A2

Application web installable, **entièrement hors ligne**, conçue pour le **Lycée Victor Laloux, Tours (37000)**.
Elle apprend à **lire**, à **former des mots** et à **écrire** — dans cet ordre, et en tenant les trois ensemble.

Pour l'installer sur les tablettes ou sur le site du lycée : voir **INSTALLATION.md**.

---

## 1. La méthode

Le contenu n'est pas une collection d'exercices : c'est une **progression syllabique explicite**, celle dont la recherche établit qu'elle fait lire — et la seule qui convienne à un apprenant qui ne décode pas encore.

Six principes, tous vérifiables dans `parcours.json` :

**1. Des correspondances graphème-phonème introduites une à une**, dans un ordre de fréquence et de régularité décroissantes. Rien n'est deviné, rien n'est laissé à l'induction.

**2. La déchiffrabilité, garantie par un contrôle automatique.** À chaque palier, tout mot donné à lire ne contient que des graphèmes déjà enseignés. Le script qui fabrique le parcours **vérifie les 54 mots et refuse de produire un fichier fautif** — il repère les graphèmes non enseignés, les lettres finales muettes prématurées, et le `s` entre deux voyelles qui se lit [z] (en épargnant le cas de la voyelle nasale, où il reste [s] : *chanson*, *danser*). C'est ce contrôle qui a fait descendre *maison* du palier 4 au palier 5.

**3. La fusion syllabique, travaillée pour elle-même.** Un exercice par palier ne fait que cela : entendre une syllabe, poser la consonne, poser la voyelle. C'est le pas décisif, celui où un apprenant bascule de la reconnaissance de lettres à la lecture.

**4. L'encodage en miroir du décodage.** Ce qui est lu dans un palier y est aussi écrit sous dictée — syllabes d'abord, mots ensuite. Lire et écrire s'étayent mutuellement ; les séparer est une perte sèche.

**5. La lecture à voix haute, à chaque palier.** Deux exercices y sont consacrés : syllabes, puis mots, avec les syllabes de deux couleurs alternées pour soutenir l'empan de l'œil.

**6. La reprise espacée.** Chaque dictée de mots se termine par deux mots des paliers antérieurs.

S'y ajoutent les **mots outils** — *la, le, un, une, est, dans, sur, avec, et* — introduits à part et reconnus globalement, parce qu'ils sont trop fréquents et trop irréguliers pour attendre, et qu'aucune phrase ne se lit sans eux.

## 2. Les six paliers

| # | Niveau | Titre | Graphèmes introduits |
|---|---|---|---|
| 1 | A1 | J'entends, je lis mes premières syllabes | a i o u e é · l m r |
| 2 | A1 | Je lis mes premiers mots | p t s n d |
| 3 | A1 | Deux lettres pour un seul son | ou on an en in ch |
| 4 | A1 | Les dernières consonnes, les sons oi, au, ai | v f b j c g · oi au eau ai ei è ê â |
| 5 | A1 | Les sons plus rares, les lettres muettes | eu gn ill qu ph z y ien oin ge · finales muettes |
| 6 | A2 | Je lis et j'écris des phrases | — (phrase, articles, genre et nombre, verbe être) |

**65 exercices, 413 questions.** Les cinq premiers paliers ont exactement la même architecture, pour que l'apprenant sache toujours où il en est :

> j'entends le son · je repère la lettre · j'assemble une syllabe · je lis des syllabes · j'écris des syllabes · je lis des mots · les mots à retenir · je comprends ce que je lis · je remets les syllabes en ordre · j'écris des mots · je trace les lettres nouvelles

Un palier s'ouvre quand le précédent est terminé avec une moyenne d'au moins 60 sur 100 (65 pour l'entrée en A2). Le réglage *Paliers → Tous ouverts* lève ce verrou quand l'enseignant veut travailler un palier hors séquence.

## 3. Les six formats d'exercices

| Format | `type` | Ce qu'il fait travailler |
|---|---|---|
| Choix multiple | `choix` | discrimination auditive, son → lettre, mots outils, compréhension, grammaire |
| Mise en ordre | `sequence` | fusion consonne + voyelle, syllabes d'un mot, mots d'une phrase |
| **Lecture à voix haute** | `lecture` | syllabes, mots syllabés en couleurs, phrases |
| Composition | `dictee` | écrire une syllabe, un mot, à l'oreille |
| Tracé guidé | `trace` | le geste d'écriture, lettre par lettre puis mot entier |
| Jeu chronométré | `chrono` | automatisation, rythme |

### Une franchise sur la lecture à voix haute

Aucune application hors ligne ne peut vérifier qu'un mot a été bien lu : il faudrait de la reconnaissance vocale, donc un serveur, donc du réseau et des données qui sortent. Le format `lecture` l'assume : l'apprenant lit, écoute le modèle, puis **se juge lui-même** — *je l'ai bien lu* ou *pas encore*. L'application le dit dans la consigne et note un peu moins celui qui a écouté avant de se prononcer. C'est un exercice d'honnêteté autant que de lecture, et c'est ainsi que l'apprenant se surveille quand l'enseignant est ailleurs dans la salle. En atelier, c'est évidemment le moment où l'on passe écouter.

## 4. Modifier le contenu sans développeur

`parcours.json` contient tout. Deux voies :

- **Depuis l'application** : Réglages → Contenu pédagogique → *Exporter le parcours*, on modifie, *Importer un parcours*. L'application **vérifie le fichier avant de l'accepter** et refuse en le disant un exercice sans bonne réponse, une séquence sans cible, une dictée sans mot, une lecture sans texte, un tracé appelant une lettre inconnue.
- **Sur le serveur** : remplacer `parcours.json`. Les tablettes vont chercher ce fichier sur le réseau en priorité : la mise à jour arrive à la prochaine connexion, sans réinstallation.

Les formats, un exemple chacun :

```json
{ "type": "choix",   "questions": [ { "invite": { "audio": "la", "libelle": "la syllabe" },
                                      "reponse": "l", "choix": ["l", "m", "r"] } ] }

{ "type": "sequence","questions": [ { "cible": ["ch", "ou"], "banque": ["ch", "ou", "m", "an"],
                                      "invite": { "audio": "chou", "libelle": "la syllabe" } } ] }

{ "type": "lecture", "questions": [ { "texte": "mouton", "syllabes": ["mou", "ton"],
                                      "audio": "mouton" } ] }

{ "type": "dictee",  "questions": [ { "mot": "lama", "invite": { "audio": "lama", "libelle": "le mot" } } ] }

{ "type": "trace",   "questions": [ { "glyphes": ["l", "a", "m", "a"] } ] }

{ "type": "chrono",  "questions": [ { "lettres": ["a", "b", "c"], "temps": 60 } ] }
```

`syllabes` colore les syllabes alternativement ; leur concaténation doit reconstituer `texte` (l'application le vérifie). `banque` ajoute des étiquettes pièges. `competence` alimente le tableau de bord.

**Vingt-sept pictogrammes** dessinés au trait, embarqués, sans image à télécharger : maison, arbre, soleil, lune, chat, poisson, livre, porte, tasse, clé, vélo, table, bateau, étoile, pain, pomme, fleur, ballon, banane, lit, sac, robe, mur, feu, chapeau, orange, chaise.

**Tracés disponibles** : les 26 minuscules cursives, les 26 majuscules, `é è ê à ù ç`, et six gestes de base (`geste-trait`, `geste-vague`, `geste-boucle`, `geste-rond`, `geste-pont`, `geste-jambage`).

### Ajouter un palier

Le fichier `parcours2.py` (joint) fabrique le parcours et porte le contrôle de déchiffrabilité. Pour ajouter un palier 7, on y ajoute une entrée dans `PALIERS` — graphèmes, syllabes sous forme de paires consonne/voyelle, mots avec leur découpe syllabique et leur catégorie — et les onze exercices sont engendrés automatiquement, déjà vérifiés. C'est la manière la plus sûre d'étendre le parcours : elle rend impossible le mot qu'on ne peut pas encore lire.

## 5. Sur tablette

Cibles tactiles élargies (84 px de haut en mode exercice), zoom et rebond désactivés, mode plein écran dans les Réglages, mise en page adaptée au format paysage et aux écrans bas. Trois tailles de texte, un mode à contraste renforcé, trois largeurs d'aide au tracé. Navigation complète au clavier, focus visible, animations supprimées si le système le demande.

## 6. Les comptes

Pseudo + **code à trois chiffres et une lettre** (`482K`). Plusieurs profils par appareil. Rien ne sort de la tablette : IndexedDB, à défaut le stockage du navigateur, à défaut la mémoire vive — l'écran Réglages dit lequel est actif et prévient quand rien ne sera conservé. *Exporter* / *Importer* déplacent un parcours d'un poste à l'autre, et servent de sauvegarde.

## 7. Ce que cette application ne fait pas

Elle n'enseigne pas la compréhension de texte au-delà du mot et de la phrase simple. Elle ne travaille ni l'oral en interaction, ni l'écrit long. Elle ne remplace pas un formateur : elle donne à l'apprenant de quoi s'exercer seul, longtemps, sans se tromper de chemin — ce qui est déjà beaucoup, et ce que le temps d'atelier permet rarement.

Le palier 6 s'appelle « Je lis et j'écris des phrases », non « A2 atteint ». Il amène à la porte de l'A2 écrit. La structure du contenu est faite pour que les paliers suivants s'ajoutent sans qu'on rouvre le code.

---

*Livré pour le Lycée Victor Laloux, Tours (37000).*
