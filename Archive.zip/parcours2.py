# -*- coding: utf-8 -*-
"""
Parcours « J'écris en français » — apprendre à lire, à former des mots, à écrire.

Principes tenus, et vérifiables dans le fichier produit :

1. CORRESPONDANCES GRAPHÈME-PHONÈME EXPLICITES, introduites dans un ordre
   de fréquence et de régularité croissantes. Rien n'est deviné.
2. DÉCHIFFRABILITÉ : à chaque palier, tout mot donné à lire ne contient que
   des graphèmes déjà enseignés. Le script le VÉRIFIE et refuse de produire
   un fichier fautif.
3. FUSION SYLLABIQUE explicite (consonne + voyelle → syllabe), qui est le
   pas décisif vers la lecture.
4. ENCODAGE EN MIROIR : ce qui est lu est aussi écrit (dictée), dans le même
   palier. Lire et écrire s'étayent l'un l'autre.
5. LECTURE À VOIX HAUTE à chaque palier — l'acte central.
6. REPRISE ESPACÉE : chaque palier reprend des mots des paliers antérieurs.
7. MOTS OUTILS fréquents et irréguliers, introduits à part, comme mots à
   retenir globalement, parce qu'ils sont indispensables aux phrases.
8. COMPRÉHENSION dès le palier 1 : lire un mot, c'est y associer un sens.

Architecture identique dans chaque palier — l'apprenant sait toujours où il
en est : j'entends · je repère la lettre · j'assemble · je lis · j'écris ·
je comprends · je trace.
"""
import json, unicodedata, random

random.seed(7)

# =====================================================================
#  1. LA PROGRESSION
# =====================================================================

PALIERS = [
    dict(
        n=1, niveau="A1", titre="J'entends, je lis mes premières syllabes", seuil=60,
        resume="Les cinq voyelles et trois consonnes. Assembler une consonne et une voyelle : le geste qui ouvre la lecture.",
        graphemes=["a", "i", "o", "u", "e", "é", "l", "m", "r"],
        voyelles=["a", "i", "o", "u", "é"],
        consonnes=["l", "m", "r"],
        syllabes=[[c, v] for c in ["l", "m", "r"] for v in ["a", "i", "o", "u"]],
        cible_son="a",
        tracer=["a", "i", "o", "u", "l", "m", "r"],
        outils=["la", "le", "il", "elle"],
        mots=[
            ("ami", ["a", "mi"], None, "une personne"),
            ("mari", ["ma", "ri"], None, "une personne"),
            ("mur", ["mur"], "mur", "un objet"),
            ("lama", ["la", "ma"], None, "un animal"),
            ("rame", ["ra", "me"], None, "un objet"),
            ("lime", ["li", "me"], None, "un objet"),
            ("mule", ["mu", "le"], None, "un animal"),
        ],
        avec_son=["lama", "rame", "ami", "mari"],
        sans_son=["mur", "lime", "mule"],
    ),
    dict(
        n=2, niveau="A1", titre="Je lis mes premiers mots", seuil=60,
        resume="Cinq consonnes de plus. Assez de lettres pour lire de vrais mots de deux et trois syllabes.",
        graphemes=["p", "t", "s", "n", "d"],
        voyelles=["a", "i", "o", "u", "é"],
        consonnes=["p", "t", "s", "n", "d"],
        syllabes=[[c, v] for c in ["p", "t", "s", "n", "d"] for v in ["a", "i", "o"]],
        cible_son="i",
        tracer=["p", "t", "s", "n", "d"],
        outils=["un", "une", "des", "est"],
        mots=[
            ("papa", ["pa", "pa"], None, "une personne"),
            ("moto", ["mo", "to"], None, "un objet"),
            ("tomate", ["to", "ma", "te"], None, "un aliment"),
            ("minute", ["mi", "nu", "te"], None, "un temps"),
            ("salade", ["sa", "la", "de"], None, "un aliment"),
            ("pirate", ["pi", "ra", "te"], None, "une personne"),
            ("tulipe", ["tu", "li", "pe"], None, "une plante"),
            ("domino", ["do", "mi", "no"], None, "un objet"),
            ("animal", ["a", "ni", "mal"], None, "un mot général"),
            ("dame", ["da", "me"], None, "une personne"),
        ],
        avec_son=["minute", "pirate", "domino", "tulipe"],
        sans_son=["papa", "moto", "salade"],
    ),
    dict(
        n=3, niveau="A1", titre="Deux lettres pour un seul son", seuil=60,
        resume="ou, on, an, en, in, ch : des sons qui s'écrivent avec deux lettres. Un obstacle majeur, franchi ici.",
        graphemes=["ou", "on", "an", "en", "in", "ch"],
        voyelles=["ou", "on", "an", "in"],
        consonnes=["ch", "m", "l", "p", "t", "s", "d"],
        syllabes=[["ch", "a"], ["ch", "ou"], ["ch", "i"], ["m", "ou"], ["l", "ou"], ["p", "ou"],
                  ["s", "ou"], ["t", "on"], ["m", "on"], ["s", "on"], ["l", "an"], ["m", "an"],
                  ["p", "in"], ["l", "in"], ["m", "in"]],
        cible_son="ou",
        tracer=["c", "h", "é", "è"],
        outils=["dans", "sur", "je", "tu"],
        mots=[
            ("mouton", ["mou", "ton"], None, "un animal"),
            ("poule", ["pou", "le"], None, "un animal"),
            ("lapin", ["la", "pin"], None, "un animal"),
            ("moulin", ["mou", "lin"], None, "un objet"),
            ("chemin", ["che", "min"], None, "un lieu"),
            ("sapin", ["sa", "pin"], None, "une plante"),
            ("dimanche", ["di", "man", "che"], None, "un temps"),
            ("mandarine", ["man", "da", "ri", "ne"], None, "un aliment"),
            ("chanson", ["chan", "son"], None, "une musique"),
            ("chaton", ["cha", "ton"], None, "un animal"),
        ],
        avec_son=["mouton", "poule", "moulin"],
        sans_son=["lapin", "sapin", "chaton", "dimanche"],
    ),
    dict(
        n=4, niveau="A1", titre="Les dernières consonnes, les sons oi, au, ai", seuil=60,
        resume="v, f, b, j, c, g, puis oi, au, eau, ai. Presque toute la langue écrite devient lisible.",
        graphemes=["v", "f", "b", "j", "c", "g", "oi", "au", "eau", "ai", "ei", "è", "ê", "â"],
        voyelles=["oi", "au", "ai", "eau"],
        consonnes=["v", "f", "b", "j", "c", "g"],
        syllabes=[["v", "a"], ["v", "i"], ["f", "a"], ["f", "o"], ["b", "a"], ["b", "i"],
                  ["j", "o"], ["g", "a"], ["m", "oi"], ["t", "oi"], ["l", "oi"], ["s", "au"],
                  ["p", "eau"], ["b", "eau"], ["m", "ai"], ["l", "ai"]],
        cible_son="oi",
        tracer=["v", "f", "b", "j", "g"],
        outils=["avec", "pour", "c'est", "il y a"],
        mots=[
            ("bateau", ["ba", "teau"], "bateau", "un objet"),
            ("voiture", ["voi", "tu", "re"], None, "un objet"),
            ("gâteau", ["gâ", "teau"], None, "un aliment"),
            ("chapeau", ["cha", "peau"], "chapeau", "un vêtement"),
            ("jardin", ["jar", "din"], None, "un lieu"),
            ("table", ["ta", "ble"], "table", "un objet"),
            ("livre", ["li", "vre"], "livre", "un objet"),
            ("robe", ["ro", "be"], "robe", "un vêtement"),
            ("ballon", ["bal", "lon"], "ballon", "un objet"),
            ("banane", ["ba", "na", "ne"], "banane", "un aliment"),
            ("vélo", ["vé", "lo"], "vélo", "un objet"),
            ("cheval", ["che", "val"], None, "un animal"),
        ],
        avec_son=["voiture", "boisson", "poire"],
        sans_son=["bateau", "banane", "jardin"],
    ),
    dict(
        n=5, niveau="A1", titre="Les sons plus rares, les lettres muettes", seuil=60,
        resume="eu, gn, ill, qu, ge, s entre deux voyelles, et ces lettres finales qu'on écrit sans les entendre.",
        graphemes=["eu", "gn", "ill", "qu", "ph", "z", "y", "ien", "oin", "ge", "gi", "ss", "h", "x", "k", "w",
                   "t#", "s#", "d#", "x#"],
        voyelles=["eu", "ou", "oi", "in"],
        consonnes=["qu", "gn", "ill", "ph", "z"],
        syllabes=[["f", "eu"], ["p", "eu"], ["j", "eu"], ["l", "eu"], ["m", "eu"], ["d", "eu"],
                  ["qu", "a"], ["qu", "i"], ["gn", "a"], ["gn", "o"], ["z", "o"], ["ph", "o"]],
        cible_son="eu",
        tracer=["q", "k", "w", "x", "y", "z"],
        outils=["les", "elles", "ils", "et", "mais"],
        mots=[
            ("fleur", ["fleur"], "fleur", "une plante"),
            ("soleil", ["so", "leil"], "soleil", "le ciel"),
            ("étoile", ["é", "toi", "le"], "étoile", "le ciel"),
            ("poisson", ["pois", "son"], "poisson", "un animal"),
            ("feuille", ["feu", "ille"], None, "une plante"),
            ("montagne", ["mon", "ta", "gne"], None, "un lieu"),
            ("musique", ["mu", "si", "que"], None, "un art"),
            ("rose", ["ro", "se"], None, "une plante"),
            ("chaise", ["chai", "se"], "chaise", "un objet"),
            ("maison", ["mai", "son"], "maison", "un lieu"),
            ("chien", ["chien"], None, "un animal"),
            ("chat", ["chat"], "chat", "un animal"),
            ("orange", ["o", "ran", "ge"], "orange", "un aliment"),
            ("lit", ["lit"], "lit", "un objet"),
            ("sac", ["sac"], "sac", "un objet"),
        ],
        avec_son=["fleur", "feuille", "deux"],
        sans_son=["chaise", "musique", "orange"],
    ),
    dict(
        n=6, niveau="A2", titre="Je lis et j'écris des phrases", seuil=65,
        resume="La phrase : majuscule et point, articles, genre et nombre, premiers verbes. L'entrée dans l'A2 écrit.",
        graphemes=[],
        voyelles=[], consonnes=[],
        cible_son=None,
        tracer=[],
        outils=["je suis", "tu es", "il est", "nous sommes"],
        mots=[],
        avec_son=[], sans_son=[],
    ),
]

# =====================================================================
#  2. CONTRÔLE DE DÉCHIFFRABILITÉ
# =====================================================================

def inventaire(jusqu_a):
    g = []
    for p in PALIERS:
        if p["n"] > jusqu_a:
            break
        g += p["graphemes"]
    return sorted(set(x for x in g if not x.endswith("#")), key=len, reverse=True)

FINALES_MUETTES = {"t", "s", "d", "x", "e"}

def decoupe(mot, connus):
    """Découpe gloutonne du mot en graphèmes connus. Renvoie None si impossible."""
    m = mot.lower().replace("'", "")
    out, i = [], 0
    while i < len(m):
        for g in connus:
            if m.startswith(g, i):
                out.append(g); i += len(g); break
        else:
            return None
    return out

def controle(palier):
    """Vérifie que chaque mot du palier est déchiffrable avec ce qui est enseigné."""
    connus = inventaire(palier["n"])
    muettes_ok = palier["n"] >= 5
    pb = []
    for mot, syl, pic, cat in palier["mots"]:
        if "".join(syl) != mot.lower():
            pb.append("%s : la découpe %s ne reconstitue pas le mot" % (mot, syl))
        d = decoupe(mot, connus)
        if d is None:
            pb.append("%s : contient un graphème non enseigné au palier %d" % (mot, palier["n"]))
            continue
        if not muettes_ok and d[-1] in (FINALES_MUETTES - {"e"}):
            pb.append("%s : finale muette « %s » avant le palier 5" % (mot, d[-1]))
        # après une voyelle nasale (chanson, danser) le s reste [s] : ce n'est pas un piège
        NASALES = {"an", "en", "on", "in", "un"}
        VOY = (set("aeiouéèêâîôû") | {"ou", "oi", "au", "eau", "ai", "ei", "eu"} | NASALES)
        for k in range(1, len(d) - 1):
            if (d[k] == "s" and d[k - 1] in VOY - NASALES and d[k + 1] in VOY and not muettes_ok):
                pb.append("%s : le « s » entre deux voyelles se lit [z], non enseigné avant le palier 5" % mot)
    return pb

# =====================================================================
#  3. FABRIQUE D'EXERCICES
# =====================================================================

def melange(liste):
    l = list(liste); random.shuffle(l); return l

def choixq(invite, reponse, distracteurs):
    choix = [reponse]
    for d in distracteurs:
        if d != reponse and d not in choix:
            choix.append(d)
    assert len(choix) >= 2, (reponse, distracteurs)
    return {"invite": invite, "reponse": reponse, "choix": choix}

CATEGORIES = ["une personne", "un animal", "un aliment", "un objet", "une plante",
              "un lieu", "un temps", "un vêtement", "le ciel", "une musique", "un art", "un mot général"]

def exos_palier(p, precedents):
    """Les dix exercices d'un palier, toujours dans le même ordre."""
    ex = []
    paires = p["syllabes"][:14]
    syl = ["".join(x) for x in paires]
    mots = p["mots"]
    revision = [m for pr in precedents for m in pr["mots"]]

    # 1 — conscience phonologique : entendre le son cible
    cible = p["cible_son"]
    q = []
    for m in p["avec_son"][:4]:
        q.append(choixq({"audio": m, "libelle": "le mot"}, "oui", ["non"]))
        q[-1]["invite"]["texte"] = None
    for m in p["sans_son"][:3]:
        q.append(choixq({"audio": m, "libelle": "le mot"}, "non", ["oui"]))
    ex.append(dict(type="choix", competence="phonologie",
                   titre="J'entends le son « %s »" % cible,
                   consigne="Écoute chaque mot. Entends-tu le son « %s » ? Réponds oui ou non." % cible,
                   questions=q))

    # 2 — du son à la lettre
    q = []
    for c, v in melange(paires)[:6]:
        pool = [x for x in dict.fromkeys([a for a, b in paires] + ["l", "m", "t", "s", "p"]) if x != c]
        autres = melange(pool)[:2]
        q.append(choixq({"audio": c + v, "libelle": "la syllabe"}, c, autres))
    ex.append(dict(type="choix", competence="code",
                   titre="Quelle lettre entends-tu au début ?",
                   consigne="Écoute la syllabe, puis touche la lettre par laquelle elle commence.",
                   questions=q))

    # 3 — fusion : une consonne + une voyelle
    q = []
    for c, v in melange(paires)[:6]:
        autres = (melange([x for x in set(a for a, b in paires) if x != c])[:1] +
                  melange([x for x in set(b for a, b in paires) if x != v])[:1])
        q.append({"cible": [c, v], "banque": [c, v] + autres, "invite": {"audio": c + v, "libelle": "la syllabe"}})
    ex.append(dict(type="sequence", competence="code",
                   titre="J'assemble une syllabe",
                   consigne="Écoute la syllabe, puis mets la consonne et la voyelle dans le bon ordre.",
                   questions=q))

    # 4 — lire des syllabes à voix haute
    ex.append(dict(type="lecture", competence="lecture",
                   titre="Je lis des syllabes",
                   consigne="Lis chaque syllabe à voix haute, puis écoute pour vérifier. Sois honnête avec toi-même : c'est ainsi qu'on progresse.",
                   questions=[{"texte": s, "audio": s} for s in melange(syl)[:8]]))

    # 5 — écrire des syllabes sous la dictée
    ex.append(dict(type="dictee", competence="encodage",
                   titre="J'écris des syllabes",
                   consigne="Écoute la syllabe et compose-la avec les lettres.",
                   questions=[{"mot": s, "invite": {"audio": s, "libelle": "la syllabe"}} for s in melange(syl)[:6]]))

    # 6 — lire des mots à voix haute, syllabe par syllabe
    q = []
    for mot, sy, pic, cat in mots[:8]:
        o = {"texte": mot, "syllabes": sy, "audio": mot}
        if pic:
            o["picto"] = pic
        q.append(o)
    ex.append(dict(type="lecture", competence="lecture",
                   titre="Je lis des mots",
                   consigne="Les syllabes sont de deux couleurs : lis-les l'une après l'autre, puis le mot entier.",
                   questions=q))

    # 7 — lire, c'est comprendre
    avec_image = [m for m in mots if m[2]]
    if len(avec_image) >= 4:
        q = []
        for mot, sy, pic, cat in avec_image[:6]:
            autres = melange([x[2] for x in avec_image if x[2] != pic])[:2]
            q.append(choixq({"texte": mot, "syllabes": sy}, pic, autres))
        ex.append(dict(type="choix", competence="comprehension", choixPicto=True,
                       titre="Je lis et je choisis l'image",
                       consigne="Lis le mot sans l'écouter, puis touche l'image qui lui correspond.",
                       questions=q))
    else:
        q = []
        for mot, sy, pic, cat in mots[:7]:
            autres = melange([c for c in CATEGORIES if c != cat])[:2]
            q.append(choixq({"texte": mot, "syllabes": sy}, cat, autres))
        ex.append(dict(type="choix", competence="comprehension",
                       titre="Je lis et je comprends",
                       consigne="Lis le mot, puis dis ce que c'est.",
                       questions=q))

    # 8 — reconstituer le mot avec ses syllabes
    q = []
    for mot, sy, pic, cat in [m for m in mots if len(m[1]) >= 2][:6]:
        inv = {"audio": mot, "libelle": "le mot"}
        if pic:
            inv["picto"] = pic
        q.append({"cible": sy, "banque": sy + melange(["po", "ri", "tu"])[:1], "invite": inv})
    ex.append(dict(type="sequence", competence="code",
                   titre="Je remets les syllabes en ordre",
                   consigne="Écoute le mot, puis remets ses syllabes dans l'ordre.",
                   questions=q))

    # 9 — dictée de mots, avec reprise des paliers précédents
    liste = [m[0] for m in mots[:5]] + [m[0] for m in melange(revision)[:2]]
    ex.append(dict(type="dictee", competence="encodage",
                   titre="J'écris des mots",
                   consigne="Écoute le mot et écris-le, lettre après lettre." +
                            (" Les deux derniers sont des mots des paliers précédents." if revision else ""),
                   questions=[{"mot": m, "invite": {"audio": m, "libelle": "le mot"}} for m in liste]))

    # 10 — tracer les lettres nouvelles, puis un mot
    q = [{"glyphes": [l]} for l in p["tracer"]]
    q.append({"glyphes": list(mots[0][0])})
    ex.append(dict(type="trace", competence="ecriture",
                   titre="Je trace les nouvelles lettres",
                   consigne="Pars du point orange et suis le chemin d'un seul geste. Le dernier modèle est un mot entier.",
                   questions=q))

    # bonus — les mots outils, à reconnaître d'un coup d'œil
    if p["outils"]:
        q = []
        for o in p["outils"]:
            autres = melange([x for x in sum([pp["outils"] for pp in PALIERS], []) if x != o])[:2]
            q.append(choixq({"audio": o, "libelle": "le mot"}, o, autres))
        ex.insert(6, dict(type="choix", competence="lecture",
                          titre="Les mots à retenir",
                          consigne="Ces petits mots reviennent sans cesse et ne se déchiffrent pas toujours : on les reconnaît d'un coup d'œil. Écoute, puis touche le bon.",
                          questions=q))
    return ex

# =====================================================================
#  4. PALIER 6 — la phrase
# =====================================================================

def exos_palier6():
    ex = []
    phrases = [
        ["Le", "chat", "est", "sur", "la", "table"],
        ["Je", "mange", "une", "banane"],
        ["La", "fleur", "est", "dans", "le", "jardin"],
        ["Il", "y", "a", "un", "livre", "sur", "la", "chaise"],
        ["Nous", "habitons", "à", "Tours"],
    ]
    ex.append(dict(type="sequence", competence="phrases",
                   titre="Je remets la phrase en ordre",
                   consigne="Écoute la phrase, puis remets les mots dans l'ordre. Relis-la ensuite à voix haute.",
                   questions=[{"cible": p, "invite": {"audio": " ".join(p), "libelle": "la phrase"}} for p in phrases]))

    ex.append(dict(type="lecture", competence="lecture",
                   titre="Je lis des phrases",
                   consigne="Lis chaque phrase à voix haute, d'un seul souffle, puis écoute pour vérifier.",
                   questions=[{"texte": " ".join(p) + ".", "audio": " ".join(p)} for p in phrases]))

    art = [("table", "la", "table"), ("livre", "le", "livre"), ("maison", "la", "maison"),
           ("bateau", "le", "bateau"), ("porte", "la", "porte"), ("vélo", "le", "vélo"),
           ("fleur", "la", "fleur"), ("pain", "le", "pain")]
    ex.append(dict(type="choix", competence="grammaire",
                   titre="le, la, l'",
                   consigne="Choisis l'article qui convient.",
                   questions=[choixq({"texte": "…  " + m, "picto": pic}, a, ["le" if a == "la" else "la", "l'"])
                              for m, a, pic in art]))

    un = [("table", "une", "table"), ("livre", "un", "livre"), ("chaise", "une", "chaise"),
          ("bateau", "un", "bateau"), ("étoile", "une", "étoile"), ("arbre", "un", "arbre"),
          ("orange", "une", "orange"), ("poisson", "un", "poisson")]
    ex.append(dict(type="choix", competence="grammaire",
                   titre="un ou une ?",
                   consigne="Masculin ou féminin ? Regarde l'image, écoute, puis choisis.",
                   questions=[choixq({"texte": "…  " + m, "picto": pic}, a, ["un" if a == "une" else "une"])
                              for m, a, pic in un]))

    pon = [("le chat dort", "Le chat dort."), ("je vais à tours", "Je vais à Tours."),
           ("elle mange une orange", "Elle mange une orange."), ("il fait beau", "Il fait beau."),
           ("nous sommes lundi", "Nous sommes lundi."), ("tu lis un livre", "Tu lis un livre.")]
    ex.append(dict(type="choix", competence="phrases",
                   titre="Majuscule et point",
                   consigne="Une phrase commence par une majuscule et se termine par un point.",
                   questions=[choixq({"texte": a}, b, [b.lower(), b[:-1]]) for a, b in pon]))

    plu = [("le chat", "les chats"), ("une fleur", "des fleurs"), ("le livre", "les livres"),
           ("une table", "des tables"), ("le vélo", "les vélos"), ("une porte", "des portes")]
    ex.append(dict(type="choix", competence="grammaire",
                   titre="Un seul ou plusieurs ?",
                   consigne="Mets le groupe au pluriel. Le « s » s'écrit mais ne s'entend pas.",
                   questions=[choixq({"texte": a, "audio": b, "libelle": "au pluriel"}, b, [b[:-1], a + "s"]) for a, b in plu]))

    etre = [("Je", "suis"), ("Tu", "es"), ("Il", "est"), ("Nous", "sommes"), ("Vous", "êtes"), ("Elles", "sont")]
    ex.append(dict(type="choix", competence="grammaire",
                   titre="Le verbe être",
                   consigne="Complète avec la bonne forme du verbe être.",
                   questions=[choixq({"texte": p + "  …  à Tours"}, v, [x for _, x in etre if x != v][:2]) for p, v in etre]))

    ex.append(dict(type="dictee", competence="encodage",
                   titre="J'écris des mots plus longs",
                   consigne="Écoute et écris. Prends ton temps, syllabe après syllabe.",
                   questions=[{"mot": m, "invite": {"audio": m, "libelle": "le mot"}}
                              for m in ["maison", "bateau", "chapeau", "montagne", "musique", "orange"]]))

    ex.append(dict(type="trace", competence="ecriture",
                   titre="J'écris une majuscule et des mots",
                   consigne="Les noms de villes prennent une majuscule. Elle se trace trait par trait.",
                   questions=[{"glyphes": list("Tours")}, {"glyphes": list("merci")}, {"glyphes": list("bonjour")}]))

    final = [choixq({"texte": "…  maison", "picto": "maison"}, "la", ["le", "l'"]),
             choixq({"texte": "…  livre", "picto": "livre"}, "un", ["une"]),
             choixq({"texte": "le chat"}, "les chats", ["le chats", "les chat"]),
             choixq({"texte": "je vais à tours"}, "Je vais à Tours.", ["je vais à Tours", "Je vais à tours"]),
             choixq({"texte": "Nous  …  à l'école"}, "sommes", ["est", "suis"]),
             choixq({"texte": "…  étoile", "picto": "etoile"}, "une", ["un"]),
             choixq({"texte": "Tu  …  ton nom"}, "écris", ["écrit", "écrire"]),
             choixq({"texte": "une fleur"}, "des fleurs", ["des fleur", "les fleur"]),
             choixq({"audio": "Le chat est sur la table", "libelle": "la phrase"},
                    "Le chat est sur la table.", ["le chat est sur la table", "Le chat est sur la table"]),
             choixq({"texte": "Elle  …  une orange"}, "mange", ["manges", "mangent"])]
    ex.append(dict(type="choix", competence="phrases",
                   titre="Je valide mon A2",
                   consigne="Dix questions. C'est la dernière étape du parcours.",
                   questions=final))
    return ex

# =====================================================================
#  5. ASSEMBLAGE
# =====================================================================

erreurs = []
for p in PALIERS:
    erreurs += ["Palier %d — %s" % (p["n"], e) for e in controle(p)]
if erreurs:
    print("DÉCHIFFRABILITÉ — problèmes détectés :")
    for e in erreurs:
        print("  ·", e)
    raise SystemExit(1)

paliers = []
for p in PALIERS:
    precedents = [q for q in PALIERS if q["n"] < p["n"] and q["mots"]]
    exercices = exos_palier6() if p["n"] == 6 else exos_palier(p, precedents)
    for i, e in enumerate(exercices, 1):
        e["id"] = "%d.%d" % (p["n"], i)
        for q in e["questions"]:
            if isinstance(q.get("invite"), dict):
                q["invite"] = {k: v for k, v in q["invite"].items() if v is not None}
    paliers.append(dict(n=p["n"], niveau=p["niveau"], titre=p["titre"], resume=p["resume"],
                        seuil=p["seuil"], graphemes=p["graphemes"], exercices=exercices))

parcours = {
    "version": 2,
    "etablissement": "Lycée Victor Laloux, Tours",
    "methode": "Progression syllabique explicite : correspondances graphème-phonème introduites une à une, "
               "mots strictement déchiffrables, fusion, lecture à voix haute et encodage en miroir.",
    "competences": {"phonologie": "L'oreille", "code": "Le code (lettres et sons)", "lecture": "La lecture",
                    "encodage": "L'écriture sous dictée", "comprehension": "La compréhension",
                    "ecriture": "Le geste d'écriture", "phrases": "Les phrases", "grammaire": "La grammaire"},
    "paliers": paliers
}
json.dump(parcours, open("parcours.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

n = sum(len(p["exercices"]) for p in paliers)
q = sum(len(e["questions"]) for p in paliers for e in p["exercices"])
print("déchiffrabilité : vérifiée sur %d mots" % sum(len(p["mots"]) for p in PALIERS))
print("paliers : %d · exercices : %d · questions : %d" % (len(paliers), n, q))
for p in paliers:
    t = {}
    for e in p["exercices"]:
        t[e["type"]] = t.get(e["type"], 0) + 1
    print("  palier %d (%s) %-46s %2d exercices %s" % (p["n"], p["niveau"], p["titre"][:46], len(p["exercices"]), t))
